from rest_framework import generics, permissions
from rest_framework.response import Response
from rest_framework.views import APIView
from django.contrib.auth import get_user_model
from .models import Account, Transaction, Notification, Budget
from .serializers import (
    UserSerializer,
    AccountSerializer,
    TransactionSerializer,
    NotificationSerializer,
    BudgetSerializer,
)
from rest_framework.permissions import IsAuthenticated

User = get_user_model()

class UserRegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [permissions.AllowAny]

class UserProfileView(generics.RetrieveUpdateAPIView):
    serializer_class = UserSerializer
    permission_classes = [IsAuthenticated]

    def get_object(self):
        return self.request.user

class AccountListCreateView(generics.ListCreateAPIView):
    serializer_class = AccountSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Account.objects.filter(user=self.request.user)

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)

class AccountDetailView(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = AccountSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Account.objects.filter(user=self.request.user)

class TransactionListCreateView(generics.ListCreateAPIView):
    serializer_class = TransactionSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Transaction.objects.filter(account__user=self.request.user)

    def perform_create(self, serializer):
        transaction_type = serializer.validated_data.get('transaction_type')
        amount = serializer.validated_data.get('amount')
        account = serializer.validated_data.get('account')
        related_account = serializer.validated_data.get('related_account')

        if transaction_type in ['send', 'withdraw']:
            if account.balance < amount:
                raise serializers.ValidationError("Insufficient balance for this transaction.")
            account.balance -= amount
            account.save()
        elif transaction_type == 'receive' or transaction_type == 'deposit':
            account.balance += amount
            account.save()

        # For send transactions, update related account balance
        if transaction_type == 'send' and related_account:
            related_account.balance += amount
            related_account.save()

        serializer.save()

class TransactionDetailView(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = TransactionSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Transaction.objects.filter(account__user=self.request.user)

class NotificationListView(generics.ListAPIView):
    serializer_class = NotificationSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Notification.objects.filter(user=self.request.user)

class NotificationCreateView(generics.CreateAPIView):
    serializer_class = NotificationSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)

class NotificationDetailView(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = NotificationSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Notification.objects.filter(user=self.request.user)

class BudgetListCreateView(generics.ListCreateAPIView):
    serializer_class = BudgetSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Budget.objects.filter(user=self.request.user)

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)

class BudgetDetailView(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = BudgetSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Budget.objects.filter(user=self.request.user)

class BudgetSpendingSummaryView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, format=None):
        user = request.user
        budgets = Budget.objects.filter(user=user)
        summary = []
        for budget in budgets:
            spent = Transaction.objects.filter(
                account__user=user,
                timestamp__range=(budget.start_date, budget.end_date),
                transaction_type='withdraw',
            ).aggregate(total=models.Sum('amount'))['total'] or 0
            summary.append({
                'budget_id': budget.id,
                'category': budget.category,
                'amount': budget.amount,
                'spent': spent,
                'remaining': budget.amount - spent,
                'start_date': budget.start_date,
                'end_date': budget.end_date,
            })
        return Response(summary)
